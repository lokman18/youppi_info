import React, { useState, useEffect, useMemo } from 'react';
import { useLanguage } from '../i18n/LanguageContext';
import { Link, useRouter } from '../router/Router';
import { storeService } from '../services/storeService';
import { openWhatsAppChat } from '../services/whatsappService';
import { ProductCard } from '../components/common/ProductCard';
import { QuickViewModal } from '../components/common/QuickViewModal';
import { Product } from '../types';

import heroWorkstationImg from '../assets/images/hero_laptop_workstation_1792262364586.jpg';

import { 
  ArrowRight, 
  MessageCircle, 
  ShieldCheck, 
  CheckCircle2, 
  Sparkles,
  Cpu, 
  Laptop, 
  Gamepad2, 
  HardDrive, 
  Tv, 
  Keyboard, 
  PlugZap, 
  Briefcase,
  MonitorDot,
  Truck,
  RotateCcw,
  Zap,
  Layers
} from 'lucide-react';

export const HomePage: React.FC = () => {
  const { language, t } = useLanguage();
  const { navigate } = useRouter();
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [storeVersion, setStoreVersion] = useState(0);

  useEffect(() => {
    return storeService.subscribe(() => {
      setStoreVersion(v => v + 1);
    });
  }, []);

  const featuredProducts = useMemo(() => storeService.getProducts({ isFeatured: true }).slice(0, 4), [storeVersion]);
  const latestProducts = useMemo(() => storeService.getProducts({ sortBy: 'newest' }).slice(0, 4), [storeVersion]);
  const categories = storeService.getCategories();

  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Laptop': return <Laptop className="w-4 h-4" />;
      case 'Briefcase': return <Briefcase className="w-4 h-4" />;
      case 'Gamepad2': return <Gamepad2 className="w-4 h-4" />;
      case 'MonitorDot': return <MonitorDot className="w-4 h-4" />;
      case 'Cpu': return <Cpu className="w-4 h-4" />;
      case 'Layers': return <Layers className="w-4 h-4" />;
      case 'HardDrive': return <HardDrive className="w-4 h-4" />;
      case 'Tv': return <Tv className="w-4 h-4" />;
      case 'Keyboard': return <Keyboard className="w-4 h-4" />;
      case 'PlugZap': return <PlugZap className="w-4 h-4" />;
      default: return <Laptop className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-16 lg:space-y-24 pb-20">
      
      {/* 1. Modern High-Impact Hero Section */}
      <section className="relative overflow-hidden pt-8 pb-12 lg:pt-14 lg:pb-18 bg-gradient-to-b from-white via-slate-50/50 to-slate-100/40 border-b border-slate-200/60">
        {/* Subtle Ambient Backdrops */}
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[450px] bg-red-500/5 blur-[130px] rounded-full pointer-events-none" />
        <div className="absolute top-1/4 right-0 w-[400px] h-[400px] bg-slate-400/10 blur-[110px] rounded-full pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
            
            {/* Left Column: Value Proposition & Headings */}
            <div className="lg:col-span-7 space-y-6 text-start">
              
              {/* Trust Kicker Tag */}
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-white border border-slate-200/90 rounded-full text-xs font-semibold text-slate-800 shadow-2xs">
                <span className="w-2 h-2 rounded-full bg-[#DC2626] animate-pulse" />
                <span className="text-slate-900">{t('hero.testedBadge')}</span>
                <span aria-hidden="true" className="text-slate-300">·</span>
                <span className="text-slate-500 font-normal">{t('hero.wilayaNotice')}</span>
              </div>

              {/* Dynamic Main Title */}
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-slate-900 leading-[1.14] text-balance">
                {t('hero.headline')}
              </h1>

              {/* Lead Paragraph */}
              <p className="text-base sm:text-lg text-slate-600 max-w-xl leading-relaxed">
                {t('hero.description')}
              </p>

              {/* Primary Call-to-Actions */}
              <div className="pt-2 flex flex-wrap items-center gap-3.5">
                <Link
                  to="/products"
                  className="px-6 py-3.5 bg-[#DC2626] hover:bg-[#B91C1C] active:bg-[#991B1B] text-white text-sm font-bold rounded-xl shadow-md shadow-red-600/25 hover:shadow-lg hover:shadow-red-600/35 transition-all flex items-center gap-2 group cursor-pointer"
                >
                  <span>{t('hero.ctaPrimary')}</span>
                  <ArrowRight className="w-4 h-4 rtl:rotate-180 group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform" />
                </Link>

                <button
                  onClick={() => openWhatsAppChat({ sourcePage: 'hero', lang: language })}
                  className="px-5 py-3.5 bg-white hover:bg-slate-50 border border-slate-200/90 hover:border-slate-300 text-slate-800 text-sm font-bold rounded-xl transition-all shadow-xs flex items-center gap-2 cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4 text-[#25D366]" />
                  <span>{t('hero.ctaSecondary')}</span>
                </button>
              </div>

              {/* Quantitative Quality Proof Strip */}
              <div className="pt-6 border-t border-slate-200/80 grid grid-cols-3 gap-4 text-xs text-slate-500">
                <div className="space-y-0.5">
                  <span className="text-slate-900 font-extrabold block text-sm font-mono tabular-nums">100% Testé</span>
                  <span className="text-slate-500">{t('trust.inspectedTitle')}</span>
                </div>
                <div className="space-y-0.5">
                  <span className="text-slate-900 font-extrabold block text-sm font-mono tabular-nums">Grade A / A+</span>
                  <span className="text-slate-500">{t('trust.transparentTitle')}</span>
                </div>
                <div className="space-y-0.5">
                  <span className="text-slate-900 font-extrabold block text-sm font-mono tabular-nums">58 Wilayas</span>
                  <span className="text-slate-500">Livraison Yalidine</span>
                </div>
              </div>
            </div>

            {/* Right Column: Hardware Showcase Feature Card */}
            <div className="lg:col-span-5 relative">
              <div className="relative rounded-2xl overflow-hidden border border-slate-200/90 bg-white shadow-xl shadow-slate-900/5 group">
                <img
                  src={heroWorkstationImg}
                  alt="YOUPPI INFO Flagship Laptop Workstation"
                  className="w-full h-[380px] lg:h-[450px] object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                />
                
                {/* Visual Gradient Scrim */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-slate-950/20 to-transparent" />

                {/* Floating Showcase Overlay */}
                <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl bg-white/95 backdrop-blur-md border border-slate-200/90 shadow-lg flex items-center justify-between gap-4">
                  <div>
                    <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-[#DC2626] block">
                      Arrivage Suisse & Europe
                    </span>
                    <h4 className="text-sm font-bold text-slate-900">ThinkPad, EliteBook & PC Gamer</h4>
                    <span className="text-xs text-slate-500">Garantie d'atelier 30 jours avec facture</span>
                  </div>
                  <Link
                    to="/products"
                    className="p-3 bg-[#DC2626] hover:bg-[#B91C1C] text-white rounded-xl transition-colors shrink-0 shadow-xs cursor-pointer"
                    aria-label="Voir le catalogue"
                  >
                    <ArrowRight className="w-4 h-4 rtl:rotate-180" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Interactive Quick Category Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-[#DC2626] mb-1">
              Catégories en Vedette
            </div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">{t('categories.title')}</h2>
          </div>
          <Link
            to="/products"
            className="text-xs font-bold text-[#DC2626] hover:text-[#B91C1C] flex items-center gap-1.5 transition-colors group"
          >
            <span>{t('categories.viewAll')}</span>
            <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180 group-hover:translate-x-0.5 transition-transform" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 sm:gap-4">
          {categories.slice(0, 10).map((cat) => (
            <Link
              key={cat.id}
              to={`/categories/${cat.slug}`}
              className="p-4 rounded-xl bg-white border border-slate-200/90 hover:border-slate-300 hover:shadow-md transition-all group flex flex-col justify-between h-28"
            >
              <div className="w-8 h-8 rounded-lg bg-slate-100 group-hover:bg-red-50 text-slate-600 group-hover:text-[#DC2626] flex items-center justify-center transition-colors">
                {getCategoryIcon(cat.iconName)}
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-800 group-hover:text-[#DC2626] transition-colors truncate">
                  {language === 'ar' ? cat.nameAr : language === 'en' ? cat.nameEn : cat.nameFr}
                </h4>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* 3. Featured Hardware Selection */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-[#DC2626] mb-1">
              Top Sélections
            </div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Sélection Recommandée</h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">Configurations haut de gamme plébiscitées pour leur fiabilité</p>
          </div>
          <Link
            to="/products?sort=featured"
            className="text-xs font-bold text-[#DC2626] hover:text-[#B91C1C] flex items-center gap-1.5 transition-colors group"
          >
            <span>{t('catalog.sortFeatured')}</span>
            <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180 group-hover:translate-x-0.5 transition-transform" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onQuickView={(p) => setQuickViewProduct(p)}
            />
          ))}
        </div>
      </section>

      {/* 4. Trust & Quality Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          <div className="p-6 rounded-2xl bg-white border border-slate-200/90 shadow-xs space-y-2.5">
            <div className="w-10 h-10 rounded-xl bg-red-50 text-[#DC2626] flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900">{t('trust.inspectedTitle')}</h3>
            <p className="text-xs text-slate-500 leading-relaxed">{t('trust.inspectedDesc')}</p>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-slate-200/90 shadow-xs space-y-2.5">
            <div className="w-10 h-10 rounded-xl bg-red-50 text-[#DC2626] flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900">{t('trust.transparentTitle')}</h3>
            <p className="text-xs text-slate-500 leading-relaxed">{t('trust.transparentDesc')}</p>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-slate-200/90 shadow-xs space-y-2.5">
            <div className="w-10 h-10 rounded-xl bg-red-50 text-[#DC2626] flex items-center justify-center">
              <Truck className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900">Livraison 58 Wilayas</h3>
            <p className="text-xs text-slate-500 leading-relaxed">Expédition sécurisée avec Yalidine Express à domicile ou stop-desk.</p>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-slate-200/90 shadow-xs space-y-2.5">
            <div className="w-10 h-10 rounded-xl bg-red-50 text-[#DC2626] flex items-center justify-center">
              <MessageCircle className="w-5 h-5 text-[#25D366]" />
            </div>
            <h3 className="text-sm font-bold text-slate-900">{t('trust.whatsappTitle')}</h3>
            <p className="text-xs text-slate-500 leading-relaxed">{t('trust.whatsappDesc')}</p>
          </div>
        </div>
      </section>

      {/* 5. Latest Arrivals */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-[#DC2626] mb-1">
              Derniers Arrivages
            </div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Derniers Arrivages en Stock</h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">Matériel inspecté et prêt à l'emploi</p>
          </div>
          <Link
            to="/products?sort=newest"
            className="text-xs font-bold text-[#DC2626] hover:text-[#B91C1C] flex items-center gap-1.5 transition-colors group"
          >
            <span>{t('catalog.sortNewest')}</span>
            <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180 group-hover:translate-x-0.5 transition-transform" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {latestProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onQuickView={(p) => setQuickViewProduct(p)}
            />
          ))}
        </div>
      </section>

      {/* 6. Technical Benchmarks & Transparency Callout */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-r from-red-50/60 via-slate-50 to-red-50/60 border border-red-200/70 relative overflow-hidden shadow-xs">
          <div className="max-w-2xl space-y-4 relative z-10">
            <span className="text-xs font-mono uppercase tracking-wider font-bold text-[#DC2626] block">
              {t('about.benchmarksTitle')}
            </span>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Chaque ordinateur d’occasion fait l’objet d’un audit sans compromis
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Nous n’achetons ni ne revendons de matériel à l’aveugle. Nous testons chaque cœur CPU avec Cinebench, la mémoire vive avec MemTest86, l’état des cellules de batterie et la résistance thermique sous FurMark.
            </p>
            <div className="pt-2 flex flex-wrap gap-3.5">
              <Link
                to="/about"
                className="px-5 py-3 bg-white hover:bg-slate-100 border border-slate-200/90 text-slate-800 text-xs font-bold rounded-xl transition-colors flex items-center gap-2 shadow-2xs cursor-pointer"
              >
                <span>{t('nav.about')}</span>
                <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180" />
              </Link>
              <button
                onClick={() => openWhatsAppChat({ sourcePage: 'why_youppi', lang: language })}
                className="px-5 py-3 bg-[#DC2626] hover:bg-[#B91C1C] text-white text-xs font-bold rounded-xl transition-colors flex items-center gap-2 shadow-sm shadow-red-600/25 cursor-pointer"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>{t('contact.openWhatsApp')}</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Quick View Modal */}
      {quickViewProduct && (
        <QuickViewModal
          product={quickViewProduct}
          onClose={() => setQuickViewProduct(null)}
        />
      )}
    </div>
  );
};
