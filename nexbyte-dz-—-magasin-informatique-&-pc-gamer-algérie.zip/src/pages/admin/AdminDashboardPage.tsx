import React from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useRouter, Link } from '../../router/Router';
import { storeService } from '../../services/storeService';
import { AdminLayout } from './AdminLayout';
import { 
  Package, 
  Plus, 
  ArrowRight,
  Boxes,
  MessageCircle
} from 'lucide-react';

export const AdminDashboardPage: React.FC = () => {
  const { language, t, formatPrice } = useLanguage();
  const { navigate } = useRouter();

  const metrics = storeService.getDashboardMetrics();
  const recentProducts = storeService.getProducts({ isAdmin: true }).slice(0, 5);
  const recentInquiries = storeService.getInquiries().slice(0, 5);

  return (
    <AdminLayout activeTab="dashboard">
      <div className="space-y-8">
        
        {/* Top Title & Primary Actions */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              {t('admin.dashboard')}
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">
              Vue synthétique du stock, alertes d’approvisionnement et flux WhatsApp
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <Link
              to="/admin/products/new"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#EF4444] hover:bg-[#DC2626] text-white text-xs font-semibold rounded-lg shadow-sm shadow-[#EF4444]/25"
            >
              <Plus className="w-4 h-4" />
              <span>{t('admin.addProduct')}</span>
            </Link>
          </div>
        </div>

        {/* Key Metrics Cards Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs space-y-1">
            <span className="text-xs text-slate-500 font-medium">{t('admin.totalProducts')}</span>
            <div className="text-2xl font-bold text-slate-900 tabular-nums">{metrics.totalProducts}</div>
            <span className="text-[11px] text-slate-400">Références au catalogue</span>
          </div>

          <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs space-y-1">
            <span className="text-xs text-slate-500 font-medium">{t('admin.availableCount')}</span>
            <div className="text-2xl font-bold text-emerald-600 tabular-nums">{metrics.availableProducts}</div>
            <span className="text-[11px] text-emerald-600/80">En rayon immédiatement</span>
          </div>

          <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs space-y-1">
            <span className="text-xs text-slate-500 font-medium">{t('admin.lowStockAlerts')}</span>
            <div className={`text-2xl font-bold tabular-nums ${metrics.lowStockProducts > 0 ? 'text-amber-600' : 'text-slate-800'}`}>
              {metrics.lowStockProducts}
            </div>
            <span className="text-[11px] text-slate-400">Sous le seuil d'alerte</span>
          </div>

          <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs space-y-1">
            <span className="text-xs text-slate-500 font-medium">{t('admin.totalInquiries')}</span>
            <div className="text-2xl font-bold text-[#EF4444] tabular-nums">{metrics.totalInquiriesCount}</div>
            <span className="text-[11px] text-slate-400">Clics acheteurs enregistrés</span>
          </div>
        </div>

        {/* Financial & Inventory Value Strip */}
        <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider block">
              {t('admin.totalInventoryValue')}
            </span>
            <span className="text-2xl font-extrabold text-slate-900 tabular-nums">
              {formatPrice(metrics.totalInventoryValueDzd)}
            </span>
            <span className="text-[11px] text-slate-500 block">
              Valeur marchande cumulée des produits disponibles à la vente
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Link
              to="/admin/inventory"
              className="px-3.5 py-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-xs font-semibold text-slate-800 flex items-center gap-2 shadow-2xs"
            >
              <Boxes className="w-4 h-4 text-[#EF4444]" />
              <span>Gérer les stocks</span>
            </Link>
          </div>
        </div>

        {/* Two-Column Breakdown: Recent Products & Recent Stock Movements */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Col 1: Recently Added / Managed Products */}
          <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Package className="w-4 h-4 text-[#EF4444]" />
                <span>Derniers produits en stock</span>
              </h3>
              <Link to="/admin/products" className="text-xs text-[#EF4444] hover:underline flex items-center gap-1 font-semibold">
                <span>Voir tout</span>
                <ArrowRight className="w-3 h-3 rtl:rotate-180" />
              </Link>
            </div>

            <div className="space-y-2.5">
              {recentProducts.map((p) => (
                <div
                  key={p.id}
                  className="p-2.5 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="truncate flex-1">
                    <span className="font-semibold text-slate-900 truncate block">{p.name}</span>
                    <span className="text-[11px] text-slate-500 font-mono">{p.sku} · {p.brand}</span>
                  </div>
                  <div className="text-end shrink-0">
                    <span className="font-bold text-slate-900 block tabular-nums">{formatPrice(p.priceDzd)}</span>
                    <span className={`text-[10px] font-semibold ${
                      p.status === 'available' ? 'text-emerald-600' : p.status === 'reserved' ? 'text-amber-600' : 'text-red-600'
                    }`}>
                      {t(`statuses.${p.status}`)} ({p.stockQuantity} pcs)
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Col 2: Recent WhatsApp Inquiries */}
          <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-[#25D366]" />
                <span>Demandes WhatsApp récentes</span>
              </h3>
              <Link to="/admin/inquiries" className="text-xs text-[#EF4444] hover:underline flex items-center gap-1 font-semibold">
                <span>Journal</span>
                <ArrowRight className="w-3 h-3 rtl:rotate-180" />
              </Link>
            </div>

            {recentInquiries.length > 0 ? (
              <div className="space-y-2.5">
                {recentInquiries.map((inq) => (
                  <div
                    key={inq.id}
                    className="p-2.5 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="truncate flex-1">
                      <span className="font-semibold text-slate-900 truncate block">{inq.productName}</span>
                      <span className="text-[11px] text-slate-500 font-mono">{inq.productSku} · Page: {inq.sourcePage}</span>
                    </div>
                    <div className="text-end shrink-0">
                      <span className="font-semibold text-[#EF4444] block tabular-nums">{formatPrice(inq.priceDzd)}</span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {new Date(inq.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center text-xs text-slate-500">
                Aucune demande WhatsApp enregistrée pour l'instant. Les clics visiteurs apparaîtront ici.
              </div>
            )}
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};
