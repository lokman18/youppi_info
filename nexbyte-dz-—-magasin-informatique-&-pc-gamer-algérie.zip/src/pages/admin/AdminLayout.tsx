import React, { useState } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useRouter, Link } from '../../router/Router';
import { authService } from '../../services/authService';
import { 
  LayoutDashboard, 
  Package, 
  Boxes, 
  Layers, 
  MessageCircle, 
  Settings, 
  LogOut, 
  ExternalLink,
  Menu,
  X
} from 'lucide-react';

interface AdminLayoutProps {
  children: React.ReactNode;
  activeTab: 'dashboard' | 'products' | 'inventory' | 'categories' | 'inquiries' | 'settings';
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({ children, activeTab }) => {
  const { language, t } = useLanguage();
  const { navigate, pathname } = useRouter();
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  const currentUser = authService.getCurrentUser();

  const handleLogout = () => {
    authService.logout();
    navigate('/admin/login');
  };

  const isClerk = currentUser?.role === 'inventory_clerk';

  const navItems = isClerk
    ? [
        { id: 'inventory', label: t('clerk.title'), icon: Boxes, path: '/stock' },
        { id: 'products', label: language === 'ar' ? 'إضافة وحذف العتاد' : 'Gestion des Matériels', icon: Package, path: '/admin/products' },
        { id: 'inventory_history', label: language === 'ar' ? 'سجل حركات المخزون' : 'Mouvements de Stock', icon: Boxes, path: '/admin/inventory' },
      ]
    : [
        { id: 'dashboard', label: t('admin.dashboard'), icon: LayoutDashboard, path: '/admin' },
        { id: 'products', label: t('admin.products'), icon: Package, path: '/admin/products' },
        { id: 'inventory', label: t('admin.inventory'), icon: Boxes, path: '/admin/inventory' },
        { id: 'categories', label: t('admin.categories'), icon: Layers, path: '/admin/categories' },
        { id: 'inquiries', label: t('admin.inquiries'), icon: MessageCircle, path: '/admin/inquiries' },
        { id: 'settings', label: t('admin.settings'), icon: Settings, path: '/admin/settings' },
      ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row text-slate-800">
      
      {/* Mobile Top Header */}
      <div className="md:hidden flex items-center justify-between p-4 bg-white border-b border-slate-200 sticky top-0 z-40 shadow-xs">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded bg-gradient-to-br from-[#DC2626] to-[#94A3B8] flex items-center justify-center text-[10px] font-black text-white">
            YI
          </div>
          <span className="text-sm font-bold tracking-tight text-slate-900">YOUPPI ADMIN</span>
        </div>
        <button
          onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
          className="p-1.5 text-slate-600 hover:text-slate-900"
        >
          {mobileSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Admin Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 rtl:left-auto rtl:right-0 z-50 w-64 bg-white border-r rtl:border-r-0 rtl:border-l border-slate-200 flex flex-col justify-between transition-transform duration-200 shadow-sm
        md:static md:translate-x-0 ${mobileSidebarOpen ? 'translate-x-0' : '-translate-x-full rtl:translate-x-full'}
      `}>
        <div className="p-5 space-y-6">
          {/* Brand Monogram Header */}
          <div className="flex items-center justify-between">
            <Link to="/admin" className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#DC2626] via-[#DC2626] to-[#94A3B8] flex items-center justify-center p-[1px] shadow-xs">
                <div className="w-full h-full bg-white rounded-[7px] flex items-center justify-center">
                  <span className="text-xs font-black text-[#DC2626]">YI</span>
                </div>
              </div>
              <div>
                <span className="text-sm font-bold tracking-tight text-slate-900 block">YOUPPI INFO</span>
                <span className="text-[10px] font-mono font-bold text-[#DC2626] block">ADMIN PORTAL</span>
              </div>
            </Link>
            <button
              onClick={() => setMobileSidebarOpen(false)}
              className="md:hidden text-slate-400 p-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Dev/Standalone indicator */}
          <div className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-[11px] text-slate-600 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
            <span className="truncate">Stockage Local / Supabase Ready</span>
          </div>

          {/* Navigation Links */}
          <nav className="space-y-1 text-xs">
            {navItems.map((item) => {
              const active = activeTab === item.id;
              const Icon = item.icon;
              return (
                <Link
                  key={item.id}
                  to={item.path}
                  onClick={() => setMobileSidebarOpen(false)}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium transition-colors ${
                    active
                      ? 'bg-[#DC2626] text-white shadow-xs font-semibold'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-slate-200 space-y-3 text-xs bg-slate-50/50">
          <div className="flex items-center justify-between text-slate-500">
            <span className="truncate font-semibold text-slate-800">
              {currentUser?.displayName || 'Admin'}
            </span>
            <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 bg-slate-100 border border-slate-200 rounded text-slate-600 font-bold">
              {currentUser?.role === 'super_admin' ? 'Owner' : 'Manager'}
            </span>
          </div>

          <div className="space-y-2 pt-1">
            {!isClerk && (
              <Link
                to="/stock"
                className="w-full py-1.5 px-2.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 rounded text-[11px] font-semibold flex items-center justify-between transition-colors shadow-2xs"
              >
                <span>{language === 'ar' ? 'لوحة أمين المخزن' : 'Terminal Entrepôt'}</span>
                <span className="font-mono text-[9px] bg-emerald-100 text-emerald-800 px-1 rounded font-bold">Stock IN/OUT</span>
              </Link>
            )}

            <div className="flex items-center justify-between">
              <Link
                to="/"
                className="flex items-center gap-1.5 text-slate-600 hover:text-[#DC2626] text-[11px] transition-colors"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Voir la boutique</span>
              </Link>

              <button
                onClick={handleLogout}
                className="flex items-center gap-1.5 text-red-600 hover:text-red-700 text-[11px] transition-colors font-semibold"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>{t('admin.logout')}</span>
              </button>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Admin Content Canvas */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto max-w-7xl">
        {children}
      </main>
    </div>
  );
};
