import React, { useState } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useRouter, Link } from '../../router/Router';
import { authService } from '../../services/authService';
import { Lock, User, ArrowLeft, Eye, EyeOff, AlertCircle } from 'lucide-react';

export const AdminLoginPage: React.FC = () => {
  const { language, t } = useLanguage();
  const { navigate } = useRouter();

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!username.trim() || !password.trim()) {
      setError(language === 'ar' ? 'يرجى إدخال اسم المستخدم وكلمة المرور' : 'Veuillez saisir votre nom d’utilisateur et mot de passe.');
      return;
    }

    setLoading(true);

    setTimeout(() => {
      const res = authService.login(username.trim(), password.trim());
      if (res.success) {
        if (res.role === 'inventory_clerk') {
          navigate('/stock');
        } else {
          navigate('/admin');
        }
      } else {
        setError(res.error || (language === 'ar' ? 'بيانات الدخول غير صحيحة.' : 'Identifiants invalides.'));
      }
      setLoading(false);
    }, 200);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white border border-slate-200 rounded-2xl shadow-xl p-7 sm:p-8 space-y-6">
        
        {/* Brand Lockup */}
        <div className="text-center space-y-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#EF4444] via-[#DC2626] to-[#94A3B8] flex items-center justify-center p-[1px] mx-auto shadow-sm shadow-[#EF4444]/30">
            <div className="w-full h-full bg-white rounded-[10px] flex items-center justify-center">
              <span className="text-sm font-black text-[#EF4444]">YI</span>
            </div>
          </div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">
            {t('admin.loginTitle')}
          </h1>
          <p className="text-xs text-slate-500">
            {t('admin.loginSubtitle')}
          </p>
        </div>

        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} autoComplete="off" className="space-y-4 text-xs">
          <div className="space-y-1.5">
            <label className="font-semibold text-slate-700">{t('admin.username')}</label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-400 absolute left-3 rtl:left-auto rtl:right-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                autoComplete="off"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder={language === 'ar' ? 'اسم المستخدم (admin أو stock)' : 'Nom d’utilisateur (ex: admin ou stock)'}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg ps-9 pe-3 py-2 text-slate-900 placeholder-slate-400 focus:outline-none focus:border-[#EF4444]"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="font-semibold text-slate-700">{t('admin.password')}</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 rtl:left-auto rtl:right-3 top-1/2 -translate-y-1/2" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                autoComplete="new-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full bg-slate-50 border border-slate-200 rounded-lg ps-9 pe-10 py-2 text-slate-900 placeholder-slate-400 focus:outline-none focus:border-[#EF4444]"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 rtl:right-auto rtl:left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 focus:outline-none"
                tabIndex={-1}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 bg-[#EF4444] hover:bg-[#DC2626] text-white text-xs font-bold rounded-xl shadow-md shadow-[#EF4444]/25 transition-all"
          >
            {loading ? (language === 'ar' ? 'جاري التحقق...' : 'Connexion en cours...') : t('admin.signIn')}
          </button>
        </form>

        <div className="text-center pt-2">
          <Link
            to="/"
            className="inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-900 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5 rtl:rotate-180" />
            <span>Retourner au site public</span>
          </Link>
        </div>
      </div>
    </div>
  );
};
