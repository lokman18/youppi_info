import React from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { storeService } from '../../services/storeService';
import { AdminLayout } from './AdminLayout';

export const AdminInquiriesPage: React.FC = () => {
  const { language, t, formatPrice } = useLanguage();
  const inquiries = storeService.getInquiries();

  return (
    <AdminLayout activeTab="inquiries">
      <div className="space-y-6">
        <div className="pb-4 border-b border-slate-200">
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            {t('admin.inquiries')}
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Historique des clics WhatsApp émis par les visiteurs sur les fiches produits et la vitrine
          </p>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-xl text-xs text-slate-600 space-y-1 shadow-2xs">
          <span className="font-semibold text-slate-900 block">Note de transparence :</span>
          <p>
            Ces enregistrements indiquent le moment où un client potentiel a cliqué sur le bouton WhatsApp pour initier une discussion.
            Le clic ouvre l'application WhatsApp du client avec le message pré-rempli.
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-start text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 uppercase tracking-wider font-mono text-[11px]">
                <tr>
                  <th className="px-4 py-3 text-start">Date & Heure</th>
                  <th className="px-4 py-3 text-start">Produit demandé</th>
                  <th className="px-4 py-3 text-start">Réf SKU</th>
                  <th className="px-4 py-3 text-start">Prix affiché</th>
                  <th className="px-4 py-3 text-start">Provenance (Page)</th>
                  <th className="px-4 py-3 text-end">Langue</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {inquiries.length > 0 ? (
                  inquiries.map((inq) => (
                    <tr key={inq.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-4 py-3 font-mono text-slate-500 whitespace-nowrap">
                        {new Date(inq.createdAt).toLocaleString()}
                      </td>
                      <td className="px-4 py-3 font-semibold text-slate-900 max-w-xs truncate">
                        {inq.productName}
                      </td>
                      <td className="px-4 py-3 font-mono text-slate-600 font-bold">
                        {inq.productSku}
                      </td>
                      <td className="px-4 py-3 font-mono font-bold text-[#EF4444] tabular-nums">
                        {formatPrice(inq.priceDzd)}
                      </td>
                      <td className="px-4 py-3 text-slate-500 font-mono text-[11px]">
                        {inq.sourcePage}
                      </td>
                      <td className="px-4 py-3 text-end">
                        <span className="uppercase text-[10px] font-mono px-1.5 py-0.5 bg-slate-100 border border-slate-200 rounded text-slate-700 font-bold">
                          {inq.language}
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-slate-500">
                      Aucune demande WhatsApp enregistrée pour l'instant.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};
