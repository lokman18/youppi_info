import React from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { storeService } from '../../services/storeService';
import { AdminLayout } from './AdminLayout';
import { ArrowRight } from 'lucide-react';
import { Link } from '../../router/Router';

export const AdminCategoriesPage: React.FC = () => {
  const { language, t } = useLanguage();
  const categories = storeService.getCategories();

  return (
    <AdminLayout activeTab="categories">
      <div className="space-y-6">
        <div className="pb-4 border-b border-slate-200">
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            {t('admin.categories')}
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Organisation des rayons de la boutique (PC Portables, PC Gamer, Composants, Écrans...)
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {categories.map((c) => (
            <div
              key={c.id}
              className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs flex items-start justify-between gap-4"
            >
              <div className="space-y-1 text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900 text-sm">{c.nameFr}</span>
                  <span className="text-[11px] font-mono text-slate-400">({c.slug})</span>
                </div>
                <div className="text-slate-600" dir="rtl">{c.nameAr}</div>
                <p className="text-[11px] text-slate-500 pt-1 leading-relaxed">
                  {c.descriptionFr}
                </p>
              </div>

              <div className="shrink-0 flex flex-col items-end gap-2">
                <span className="px-2 py-0.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded text-[10px] font-semibold">
                  Actif
                </span>
                <Link
                  to={`/categories/${c.slug}`}
                  target="_blank"
                  className="text-[11px] text-[#EF4444] hover:underline flex items-center gap-1 font-semibold"
                >
                  <span>Voir le rayon</span>
                  <ArrowRight className="w-3 h-3 rtl:rotate-180" />
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AdminLayout>
  );
};
