import React, { useState } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { storeService } from '../../services/storeService';
import { AdminLayout } from './AdminLayout';
import { Product } from '../../types';
import { 
  Plus, 
  Minus, 
  CheckCircle2, 
  BookmarkCheck, 
  Search 
} from 'lucide-react';

export const AdminInventoryPage: React.FC = () => {
  const { language, t, formatPrice } = useLanguage();
  const [activeTab, setActiveTab] = useState<'current' | 'history'>('current');
  const [search, setSearch] = useState('');
  
  // Stock adjustment modal state
  const [adjustingProduct, setAdjustingProduct] = useState<Product | null>(null);
  const [adjDelta, setAdjDelta] = useState<number>(1);
  const [adjType, setAdjType] = useState<'stock_in' | 'stock_out' | 'sale' | 'reservation' | 'adjustment'>('stock_in');
  const [adjReason, setAdjReason] = useState('Réception nouvelle pièce');
  const [adjRef, setAdjRef] = useState('');
  const [toastMsg, setToastMsg] = useState('');
  const [refreshKey, setRefreshKey] = useState(0);

  const products = storeService.getProducts({ search, isAdmin: true });
  const movements = storeService.getInventoryMovements();

  const handleOpenAdjust = (p: Product, type: 'stock_in' | 'stock_out' | 'sale' | 'reservation' | 'adjustment') => {
    setAdjustingProduct(p);
    setAdjType(type);
    setAdjDelta(type === 'stock_out' || type === 'sale' ? -1 : 1);
    setAdjReason(
      type === 'stock_in' ? 'Arrivage atelier' :
      type === 'sale' ? 'Vente magasin / WhatsApp confirmée' :
      type === 'reservation' ? 'Réservé pour client (acompte ou envoi)' :
      'Ajustement d’inventaire manuel'
    );
    setAdjRef('');
  };

  const handleConfirmAdjust = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustingProduct) return;

    storeService.adjustStock(
      adjustingProduct.id,
      adjDelta,
      adjReason,
      adjType,
      adjRef
    );

    setAdjustingProduct(null);
    setRefreshKey(k => k + 1);
    setToastMsg(t('admin.stockAdjusted'));
    setTimeout(() => setToastMsg(''), 3000);
  };

  return (
    <AdminLayout activeTab="inventory">
      <div className="space-y-6">
        
        {/* Title */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              {t('admin.inventory')}
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">
              Suivi en temps réel des unités physiques, mouvements et réservations clients
            </p>
          </div>

          {/* Subtabs */}
          <div className="flex items-center gap-1 bg-white border border-slate-200 p-1 rounded-lg text-xs shadow-2xs">
            <button
              onClick={() => setActiveTab('current')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
                activeTab === 'current' ? 'bg-[#EF4444] text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Stock Actuel
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
                activeTab === 'history' ? 'bg-[#EF4444] text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Historique des mouvements ({movements.length})
            </button>
          </div>
        </div>

        {toastMsg && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-lg flex items-center gap-2 shadow-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="font-semibold">{toastMsg}</span>
          </div>
        )}

        {activeTab === 'current' ? (
          <div className="space-y-4">
            {/* Search */}
            <div className="relative w-full max-w-sm">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 rtl:left-auto rtl:right-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Filtrer l'inventaire par SKU, nom..."
                className="w-full bg-white border border-slate-200 rounded-lg ps-9 pe-3 py-1.5 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-[#EF4444] shadow-2xs"
              />
            </div>

            {/* Inventory Table */}
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-start text-xs">
                  <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 uppercase tracking-wider font-mono text-[11px]">
                    <tr>
                      <th className="px-4 py-3 text-start">SKU</th>
                      <th className="px-4 py-3 text-start">Produit</th>
                      <th className="px-4 py-3 text-start">État</th>
                      <th className="px-4 py-3 text-start">Prix Vente</th>
                      <th className="px-4 py-3 text-start">Quantité</th>
                      <th className="px-4 py-3 text-start">Statut</th>
                      <th className="px-4 py-3 text-end">Ajustements Rapides</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {products.map((p) => (
                      <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="px-4 py-3 font-mono font-bold text-slate-800">
                          {p.sku}
                        </td>
                        <td className="px-4 py-3 font-semibold text-slate-900 max-w-xs truncate">
                          {p.name}
                        </td>
                        <td className="px-4 py-3 text-slate-600">
                          {t(`conditions.${p.condition}`)}
                        </td>
                        <td className="px-4 py-3 font-mono font-bold text-slate-900 tabular-nums">
                          {formatPrice(p.priceDzd)}
                        </td>
                        <td className="px-4 py-3">
                          <span className={`font-mono font-bold px-2 py-0.5 rounded text-xs ${
                            p.stockQuantity === 0 
                              ? 'bg-red-50 text-red-700 border border-red-200' 
                              : p.stockQuantity <= p.lowStockThreshold 
                              ? 'bg-amber-50 text-amber-800 border border-amber-200' 
                              : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          }`}>
                            {p.stockQuantity} unité(s)
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <span className={`text-[11px] font-semibold ${
                            p.status === 'available' ? 'text-emerald-700' : p.status === 'reserved' ? 'text-amber-700' : 'text-red-700'
                          }`}>
                            {t(`statuses.${p.status}`)}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-end">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => handleOpenAdjust(p, 'stock_in')}
                              className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 rounded text-[11px] font-semibold flex items-center gap-1 shadow-2xs"
                              title="Entrée de stock (+1)"
                            >
                              <Plus className="w-3 h-3" />
                              <span>Entrée</span>
                            </button>

                            <button
                              onClick={() => handleOpenAdjust(p, 'reservation')}
                              className="px-2 py-1 bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-800 rounded text-[11px] font-semibold flex items-center gap-1 shadow-2xs"
                              title="Réserver pour un client"
                            >
                              <BookmarkCheck className="w-3 h-3" />
                              <span>Réserver</span>
                            </button>

                            <button
                              onClick={() => handleOpenAdjust(p, 'sale')}
                              disabled={p.stockQuantity <= 0}
                              className="px-2 py-1 bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-800 rounded text-[11px] font-semibold flex items-center gap-1 disabled:opacity-30 disabled:cursor-not-allowed shadow-2xs"
                              title="Enregistrer une vente (-1)"
                            >
                              <Minus className="w-3 h-3" />
                              <span>Vente</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        ) : (
          /* Mouvements History Table */
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-start text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 uppercase tracking-wider font-mono text-[11px]">
                  <tr>
                    <th className="px-4 py-3 text-start">Date & Heure</th>
                    <th className="px-4 py-3 text-start">Produit</th>
                    <th className="px-4 py-3 text-start">SKU</th>
                    <th className="px-4 py-3 text-start">Type de mouvement</th>
                    <th className="px-4 py-3 text-start">Variation</th>
                    <th className="px-4 py-3 text-start">Stock Résultant</th>
                    <th className="px-4 py-3 text-start">Motif / Référence</th>
                    <th className="px-4 py-3 text-end">Auteur</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {movements.map((m) => (
                    <tr key={m.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-4 py-3 font-mono text-slate-500 whitespace-nowrap">
                        {new Date(m.createdAt).toLocaleString()}
                      </td>
                      <td className="px-4 py-3 font-semibold text-slate-900 max-w-xs truncate">
                        {m.productName}
                      </td>
                      <td className="px-4 py-3 font-mono text-slate-600">
                        {m.productSku}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          m.movementType === 'stock_in' 
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' 
                            : m.movementType === 'sale'
                            ? 'bg-blue-50 text-blue-800 border border-blue-200'
                            : m.movementType === 'reservation'
                            ? 'bg-amber-50 text-amber-800 border border-amber-200'
                            : 'bg-slate-100 text-slate-700 border border-slate-200'
                        }`}>
                          {m.movementType}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-mono font-bold tabular-nums">
                        <span className={m.quantityDelta >= 0 ? 'text-emerald-700' : 'text-red-700'}>
                          {m.quantityDelta >= 0 ? `+${m.quantityDelta}` : m.quantityDelta}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-mono text-slate-800 tabular-nums font-semibold">
                        {m.resultingQuantity} pcs
                      </td>
                      <td className="px-4 py-3 text-slate-600 max-w-xs truncate">
                        {m.reason} {m.reference && <span className="text-slate-400 font-mono">({m.reference})</span>}
                      </td>
                      <td className="px-4 py-3 text-end text-slate-500 font-mono text-[11px]">
                        {m.createdBy}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Stock Adjustment Modal */}
        {adjustingProduct && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-fadeIn">
            <div className="bg-white border border-slate-200 rounded-2xl p-6 max-w-md w-full space-y-4 shadow-2xl">
              <h3 className="text-base font-bold text-slate-900">
                Mouvement de stock : {adjustingProduct.name}
              </h3>
              <p className="text-xs text-slate-500 font-mono">
                SKU: {adjustingProduct.sku} · Stock actuel : {adjustingProduct.stockQuantity} pcs
              </p>

              <form onSubmit={handleConfirmAdjust} className="space-y-4 text-xs">
                <div className="space-y-1.5">
                  <label className="font-semibold text-slate-700">Type d'opération</label>
                  <select
                    value={adjType}
                    onChange={(e) => setAdjType(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900 focus:outline-none focus:border-[#EF4444]"
                  >
                    <option value="stock_in">Entrée de stock (Arrivage / Réception)</option>
                    <option value="stock_out">Sortie de stock (Retour / Retrait)</option>
                    <option value="sale">Vente client</option>
                    <option value="reservation">Réservation client</option>
                    <option value="adjustment">Inventaire physique / Régularisation</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="font-semibold text-slate-700">Variation de quantité (+ ou -)</label>
                  <input
                    type="number"
                    required
                    value={adjDelta}
                    onChange={(e) => setAdjDelta(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900 font-mono focus:outline-none focus:border-[#EF4444]"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="font-semibold text-slate-700">Motif du mouvement *</label>
                  <input
                    type="text"
                    required
                    value={adjReason}
                    onChange={(e) => setAdjReason(e.target.value)}
                    placeholder="Ex: Vente comptoir, arrivage conteneur..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900 focus:outline-none focus:border-[#EF4444]"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="font-semibold text-slate-700">Référence (Optionnelle)</label>
                  <input
                    type="text"
                    value={adjRef}
                    onChange={(e) => setAdjRef(e.target.value)}
                    placeholder="Ex: Facture #1042, BL-2026-X"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900 font-mono focus:outline-none focus:border-[#EF4444]"
                  />
                </div>

                <div className="pt-2 flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setAdjustingProduct(null)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg"
                  >
                    {t('admin.cancel')}
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-[#EF4444] hover:bg-[#DC2626] text-white text-xs font-semibold rounded-lg shadow-sm"
                  >
                    Valider le mouvement
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
};
