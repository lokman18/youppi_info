import React, { useState, useEffect } from 'react';
import { useLanguage } from '../i18n/LanguageContext';
import { useRouter, Link } from '../router/Router';
import { storeService } from '../services/storeService';
import { openWhatsAppChat } from '../services/whatsappService';
import { ProductCard } from '../components/common/ProductCard';
import { Product } from '../types';
import { 
  MessageCircle, 
  ShieldCheck, 
  Truck, 
  ArrowLeft, 
  Share2, 
  Check, 
  Cpu, 
  Laptop
} from 'lucide-react';

interface ProductDetailPageProps {
  slug: string;
}

export const ProductDetailPage: React.FC<ProductDetailPageProps> = ({ slug }) => {
  const { language, t, formatPrice } = useLanguage();
  const { navigate } = useRouter();
  
  const [product, setProduct] = useState<Product | null>(null);
  const [activeImageIdx, setActiveImageIdx] = useState(0);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const found = storeService.getProductBySlug(slug, false);
    setProduct(found);
    setActiveImageIdx(0);
  }, [slug]);

  if (!product) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-xl font-bold text-slate-900">Produit introuvable</h2>
        <p className="text-sm text-slate-500">Le produit demandé n’est plus disponible ou l’adresse est incorrecte.</p>
        <Link
          to="/products"
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#DC2626] text-white text-xs font-semibold rounded-lg"
        >
          <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
          <span>{t('catalog.clearFilters')}</span>
        </Link>
      </div>
    );
  }

  const isSold = product.status === 'sold' || product.stockQuantity === 0;
  const isReserved = product.status === 'reserved';
  const images = product.images.length > 0 ? product.images : [{ id: '1', url: '', altText: product.name, isPrimary: true, sortOrder: 0 }];
  const currentImg = images[activeImageIdx] || images[0];

  // Related products from same category
  const relatedProducts = storeService
    .getProducts({ category: product.category })
    .filter(p => p.id !== product.id)
    .slice(0, 3);

  const handleWhatsApp = () => {
    openWhatsAppChat({
      product,
      sourcePage: `pdp_${product.slug}`,
      lang: language,
    });
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const hasDiscount = product.originalPriceDzd && product.originalPriceDzd > product.priceDzd;
  const discountPercent = hasDiscount 
    ? Math.round(((product.originalPriceDzd! - product.priceDzd) / product.originalPriceDzd!) * 100)
    : 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
      
      {/* Breadcrumb Navigation */}
      <nav className="flex items-center gap-2 text-xs text-slate-500">
        <Link to="/" className="hover:text-slate-900 transition-colors">{t('nav.home')}</Link>
        <span aria-hidden="true" className="text-slate-300">/</span>
        <Link to="/products" className="hover:text-slate-900 transition-colors">{t('nav.products')}</Link>
        <span aria-hidden="true" className="text-slate-300">/</span>
        <span className="text-slate-900 font-medium truncate max-w-xs">{product.name}</span>
      </nav>

      {/* Main PDP Grid: Gallery Left + Contiguous Purchase Module Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        
        {/* Left Column: Image Gallery (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="relative aspect-[4/3] bg-slate-50 rounded-2xl overflow-hidden border border-slate-200 flex items-center justify-center group shadow-md">
            {currentImg.url ? (
              <img
                src={currentImg.url}
                alt={currentImg.altText || product.name}
                referrerPolicy="no-referrer"
                className={`w-full h-full object-cover transition-transform duration-300 ${
                  isSold ? 'grayscale opacity-75' : ''
                }`}
              />
            ) : (
              <div className="flex flex-col items-center justify-center p-8 text-slate-400">
                <Laptop className="w-16 h-16 stroke-[1.2] mb-2" />
                <span className="text-xs font-mono">{product.name}</span>
              </div>
            )}

            {/* Condition Badge in Image Corner */}
            <div className="absolute top-4 left-4 rtl:left-auto rtl:right-4 flex items-center gap-2">
              <span className="bg-white/95 backdrop-blur-md text-slate-800 border border-slate-200 px-3 py-1 text-xs font-semibold rounded-md shadow-2xs">
                {t(`conditions.${product.condition}`)}
              </span>
              {hasDiscount && (
                <span className="bg-[#DC2626] text-white px-2.5 py-1 text-xs font-bold rounded-md tabular-nums shadow-2xs">
                  -{discountPercent}%
                </span>
              )}
            </div>

            {/* Status Warning Overlay if Sold or Reserved */}
            {isSold && (
              <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-6 text-center">
                <div className="bg-white border border-red-200 p-4 rounded-xl max-w-sm shadow-xl">
                  <span className="text-base font-bold text-red-600 block mb-1">
                    {t('statuses.sold')}
                  </span>
                  <p className="text-xs text-slate-600">{t('product.soldNotice')}</p>
                </div>
              </div>
            )}
            {isReserved && !isSold && (
              <div className="absolute inset-0 bg-slate-900/30 backdrop-blur-xs flex items-center justify-center p-6 text-center">
                <div className="bg-white border border-amber-200 p-4 rounded-xl max-w-sm shadow-xl">
                  <span className="text-base font-bold text-amber-700 block mb-1">
                    {t('statuses.reserved')}
                  </span>
                  <p className="text-xs text-slate-600">{t('product.reservedNotice')}</p>
                </div>
              </div>
            )}
          </div>

          {/* Thumbnails row */}
          {images.length > 1 && (
            <div className="flex items-center gap-3 overflow-x-auto pb-1">
              {images.map((img, idx) => (
                <button
                  key={img.id || idx}
                  onClick={() => setActiveImageIdx(idx)}
                  className={`w-20 h-20 rounded-xl overflow-hidden border shrink-0 transition-all ${
                    activeImageIdx === idx 
                      ? 'border-[#DC2626] ring-2 ring-red-200' 
                      : 'border-slate-200 opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img.url} alt={img.altText} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}

          {/* Trust Guarantees Strip */}
          <div className="p-4 rounded-xl bg-white border border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-slate-600 shadow-2xs">
            <div className="flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-[#DC2626] shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-slate-900 block">{t('product.warranty')}</span>
                <span className="text-slate-500">{product.specifications.warrantyPeriod || '30 jours de garantie matérielle en atelier'}</span>
              </div>
            </div>
            <div className="flex items-start gap-2.5">
              <Truck className="w-4 h-4 text-[#DC2626] shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-slate-900 block">Expédition Wilayas</span>
                <span className="text-slate-500">Emballage anti-choc et vérification au déballage</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Contiguous Purchase Module (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-7 space-y-6 sticky top-24 shadow-xs">
            
            {/* Brand, SKU & Share */}
            <div className="flex items-center justify-between text-xs text-slate-500 pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="uppercase tracking-wider font-semibold text-slate-800">{product.brand}</span>
                <span aria-hidden="true" className="text-slate-300">·</span>
                <span className="font-mono">{product.sku}</span>
              </div>
              <button
                onClick={handleShare}
                className="flex items-center gap-1.5 text-slate-500 hover:text-slate-900 transition-colors"
                title="Copier le lien"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copié !' : 'Partager'}</span>
              </button>
            </div>

            {/* Product Title */}
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 leading-tight">
              {language === 'ar' && product.nameAr ? product.nameAr : product.name}
            </h1>

            {/* Price Display */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1">
              <div className="flex items-baseline gap-3">
                <span className="text-3xl font-black text-slate-900 tabular-nums tracking-tight">
                  {formatPrice(product.priceDzd)}
                </span>
                {hasDiscount && (
                  <span className="text-sm text-slate-400 line-through tabular-nums">
                    {formatPrice(product.originalPriceDzd!)}
                  </span>
                )}
              </div>
              <span className="text-[11px] text-slate-500 block">
                Prix net en Dinars Algériens (DZD) · Paiement à la livraison possible
              </span>
            </div>

            {/* Status & Availability Details */}
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">{t('product.condition')}</span>
                <span className="text-slate-900 font-semibold">{t(`conditions.${product.condition}`)}</span>
              </div>
              <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">{t('product.status')}</span>
                <span className={`font-semibold ${isSold ? 'text-red-600' : isReserved ? 'text-amber-600' : 'text-emerald-600'}`}>
                  {t(`statuses.${product.status}`)}
                </span>
              </div>
              <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Stock</span>
                <span className="text-slate-700 font-mono">
                  {t('product.stockLeft', { count: product.stockQuantity })}
                </span>
              </div>
            </div>

            {/* Primary Action Button: WhatsApp Order */}
            <div className="space-y-3 pt-2">
              <button
                onClick={handleWhatsApp}
                disabled={isSold}
                className={`w-full py-3.5 px-6 rounded-xl text-sm font-bold flex items-center justify-center gap-2.5 transition-all shadow-md ${
                  isSold
                    ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                    : 'bg-[#DC2626] hover:bg-[#DC2626] active:bg-[#B91C1C] text-white shadow-[#DC2626]/25 hover:shadow-[#DC2626]/40 transform hover:-translate-y-0.5'
                }`}
              >
                <MessageCircle className="w-5 h-5" />
                <span>{isSold ? t('product.soldNotice') : t('product.orderWhatsApp')}</span>
              </button>

              <p className="text-[11px] text-center text-slate-500 leading-normal">
                {language === 'ar'
                  ? 'بالضغط على الزر، ستفتح محادثة مباشرة مع مستشار متجر YOUPPI INFO مع إرسال مواصفات هذا الجهاز تلقائياً.'
                  : 'En cliquant, vous ouvrez une conversation sécurisée avec un conseiller YOUPPI INFO avec les détails de ce produit pré-remplis.'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Technical Specifications Sheet */}
      <section className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xs">
        <div className="border-b border-slate-100 pb-4">
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Cpu className="w-5 h-5 text-[#DC2626]" />
            <span>{t('product.technicalSpecs')}</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Fiche technique vérifiée lors du passage au banc de test
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-3 text-xs">
          {product.specifications.cpu && (
            <div className="flex items-start justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500">{t('product.processor')}</span>
              <span className="text-slate-900 font-medium font-mono text-end max-w-xs">{product.specifications.cpu}</span>
            </div>
          )}
          {product.specifications.ram && (
            <div className="flex items-start justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500">{t('product.ram')}</span>
              <span className="text-slate-900 font-medium font-mono text-end max-w-xs">{product.specifications.ram}</span>
            </div>
          )}
          {product.specifications.storage && (
            <div className="flex items-start justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500">{t('product.storage')}</span>
              <span className="text-slate-900 font-medium font-mono text-end max-w-xs">{product.specifications.storage}</span>
            </div>
          )}
          {product.specifications.gpu && (
            <div className="flex items-start justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500">{t('product.graphics')}</span>
              <span className="text-slate-900 font-medium font-mono text-end max-w-xs">{product.specifications.gpu}</span>
            </div>
          )}
          {product.specifications.screen && (
            <div className="flex items-start justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500">{t('product.display')}</span>
              <span className="text-slate-900 font-medium text-end max-w-xs">{product.specifications.screen}</span>
            </div>
          )}
          {product.specifications.batteryHealth && (
            <div className="flex items-start justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500">{t('product.batteryHealth')}</span>
              <span className="text-emerald-600 font-semibold text-end">{product.specifications.batteryHealth}</span>
            </div>
          )}
          {product.specifications.keyboardLayout && (
            <div className="flex items-start justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500">{t('product.keyboardLayout')}</span>
              <span className="text-slate-900 font-medium text-end">{product.specifications.keyboardLayout}</span>
            </div>
          )}
          {product.specifications.cosmeticCondition && (
            <div className="flex items-start justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500">{t('product.cosmeticGrade')}</span>
              <span className="text-slate-900 font-semibold uppercase text-end">{product.specifications.cosmeticCondition}</span>
            </div>
          )}
          {product.specifications.chargerIncluded !== undefined && (
            <div className="flex items-start justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500">{t('product.charger')}</span>
              <span className="text-emerald-600 font-medium text-end">
                {product.specifications.chargerIncluded ? 'Oui (Original testé)' : 'Non inclus'}
              </span>
            </div>
          )}
          {product.specifications.knownDefects && (
            <div className="flex items-start justify-between py-2 border-b border-slate-100 md:col-span-2">
              <span className="text-slate-500">{t('product.defects')}</span>
              <span className="text-amber-700 font-medium text-end max-w-md">{product.specifications.knownDefects}</span>
            </div>
          )}
        </div>

        {/* Detailed Prose Description */}
        <div className="pt-4 border-t border-slate-100">
          <h3 className="text-sm font-bold text-slate-900 mb-2">Description du matériel</h3>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-w-3xl">
            {language === 'ar' && product.descriptionAr ? product.descriptionAr : product.description}
          </p>
        </div>
      </section>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <section className="space-y-6 pt-4">
          <div className="flex items-end justify-between">
            <h2 className="text-xl font-bold text-slate-900">{t('product.relatedProducts')}</h2>
            <Link
              to={`/categories/${product.category}`}
              className="text-xs font-semibold text-[#DC2626] hover:underline"
            >
              {t('categories.viewAll')}
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {relatedProducts.map(rel => (
              <ProductCard key={rel.id} product={rel} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
