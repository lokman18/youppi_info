import React, { useState } from 'react';
import { Product } from '../../types';
import { useLanguage } from '../../i18n/LanguageContext';
import { Link, useRouter } from '../../router/Router';
import { openWhatsAppChat } from '../../services/whatsappService';
import { MessageCircle, Eye, Laptop, ArrowUpRight } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onQuickView?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onQuickView }) => {
  const { language, t, formatPrice } = useLanguage();
  const { pathname } = useRouter();
  const [imgError, setImgError] = useState(false);

  const isSold = product.status === 'sold' || product.stockQuantity === 0;
  const isReserved = product.status === 'reserved';
  const primaryImg = product.images.find(img => img.isPrimary) || product.images[0];

  const handleWhatsAppClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    openWhatsAppChat({
      product,
      sourcePage: pathname || 'card',
      lang: language,
    });
  };

  const handleQuickView = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (onQuickView) {
      onQuickView(product);
    }
  };

  // Build clean unboxed specs string
  const specsList: string[] = [];
  if (product.specifications.cpu) {
    const match = product.specifications.cpu.match(/(i\d-\w+|Ryzen\s\d\s\w+|Core\s\w+|M\d\s\w+)/i);
    specsList.push(match ? match[0] : product.specifications.cpu.split('(')[0].trim());
  }
  if (product.specifications.ram) {
    const match = product.specifications.ram.match(/\d+\s*Go/i);
    specsList.push(match ? match[0] : product.specifications.ram.split(' ')[0]);
  }
  if (product.specifications.storage) {
    const match = product.specifications.storage.match(/\d+\s*(Go|To)/i);
    specsList.push(match ? match[0] : product.specifications.storage.split(' ')[0]);
  }
  if (product.specifications.gpu && product.category.includes('gaming')) {
    const match = product.specifications.gpu.match(/(RTX\s*\d+|GTX\s*\d+|Radeon\s*\w+)/i);
    specsList.push(match ? match[0] : 'GPU Dédié');
  }

  // Calculate discount percent if genuine original price exists
  const hasDiscount = product.originalPriceDzd && product.originalPriceDzd > product.priceDzd;
  const discountPercent = hasDiscount 
    ? Math.round(((product.originalPriceDzd! - product.priceDzd) / product.originalPriceDzd!) * 100)
    : 0;

  return (
    <div className="group relative bg-white border border-slate-200/90 hover:border-slate-300 rounded-2xl overflow-hidden shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col h-full">
      {/* Product Image Slot */}
      <div className="relative aspect-[4/3] bg-gradient-to-b from-slate-50 to-slate-100/70 overflow-hidden flex items-center justify-center">
        {primaryImg && !imgError ? (
          <img
            src={primaryImg.url}
            alt={primaryImg.altText || product.name}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className={`w-full h-full object-cover transition-transform duration-500 ease-out group-hover:scale-105 ${
              isSold ? 'grayscale opacity-60' : ''
            }`}
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-slate-50 p-4 text-slate-400">
            <Laptop className="w-10 h-10 mb-2 stroke-[1.5] text-slate-300" />
            <span className="text-xs text-slate-500 font-medium">{product.brand}</span>
          </div>
        )}

        {/* Status Overlays */}
        <div className="absolute top-3 left-3 rtl:left-auto rtl:right-3 flex flex-col gap-1.5 z-10">
          {isSold ? (
            <span className="bg-red-600 text-white px-2.5 py-1 text-[11px] font-bold tracking-wide rounded-md shadow-xs">
              {t('statuses.sold')}
            </span>
          ) : isReserved ? (
            <span className="bg-amber-500 text-white px-2.5 py-1 text-[11px] font-bold tracking-wide rounded-md shadow-xs">
              {t('statuses.reserved')}
            </span>
          ) : (
            <span className="bg-white/95 backdrop-blur-md text-slate-800 border border-slate-200/80 px-2.5 py-1 text-[11px] font-semibold rounded-md shadow-xs">
              {t(`conditions.${product.condition}`)}
            </span>
          )}

          {hasDiscount && !isSold && (
            <span className="bg-gradient-to-r from-red-600 to-rose-600 text-white px-2 py-0.5 text-[10px] font-black rounded-md tabular-nums shadow-xs">
              -{discountPercent}%
            </span>
          )}
        </div>

        {/* Quick View Button on Hover */}
        {onQuickView && (
          <button
            onClick={handleQuickView}
            className="absolute bottom-3 right-3 rtl:right-auto rtl:left-3 opacity-0 group-hover:opacity-100 transition-all duration-200 bg-white/95 hover:bg-slate-900 text-slate-700 hover:text-white border border-slate-200 hover:border-transparent p-2.5 rounded-xl backdrop-blur-md shadow-md hover:scale-105"
            aria-label="Aperçu rapide"
            title="Aperçu rapide"
          >
            <Eye className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Content Container */}
      <div className="p-5 flex flex-col flex-1 justify-between gap-4">
        <div className="space-y-2">
          {/* Brand & SKU unboxed metadata */}
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <span className="text-slate-600">{product.brand}</span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span className="font-mono text-[10px] text-slate-400">{product.sku}</span>
          </div>

          {/* Title */}
          <Link to={`/products/${product.slug}`} className="block group/title">
            <h3 className="text-sm font-bold text-slate-900 group-hover/title:text-[#DC2626] transition-colors line-clamp-2 leading-snug">
              {language === 'ar' && product.nameAr ? product.nameAr : product.name}
            </h3>
          </Link>

          {/* Technical Specs - Clean unboxed text with subtle separators */}
          {specsList.length > 0 && (
            <div className="pt-1 text-xs text-slate-600 flex items-center flex-wrap gap-1.5 leading-tight">
              {specsList.map((spec, idx) => (
                <React.Fragment key={idx}>
                  <span className="bg-slate-100/80 text-slate-700 px-2 py-0.5 rounded text-[11px] font-medium">
                    {spec}
                  </span>
                  {idx < specsList.length - 1 && (
                    <span aria-hidden="true" className="text-slate-300 text-[10px] hidden">·</span>
                  )}
                </React.Fragment>
              ))}
            </div>
          )}
        </div>

        {/* Pricing & Actions */}
        <div className="pt-3 border-t border-slate-100/90 flex flex-col gap-3">
          <div className="flex items-baseline justify-between gap-2">
            <div>
              <span className="text-xs text-slate-400 block mb-0.5 font-medium">{t('product.price')}</span>
              <div className="flex items-baseline gap-2">
                <span className="text-lg font-extrabold text-slate-900 font-mono tabular-nums tracking-tight">
                  {formatPrice(product.priceDzd)}
                </span>
                {product.originalPriceDzd && product.originalPriceDzd > product.priceDzd && (
                  <span className="text-xs text-slate-400 line-through font-mono tabular-nums">
                    {formatPrice(product.originalPriceDzd)}
                  </span>
                )}
              </div>
            </div>

            {/* Quick Stock Indicator */}
            {product.stockQuantity > 0 && product.stockQuantity <= (product.lowStockThreshold || 2) && !isSold && (
              <span className="text-[11px] font-semibold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-md">
                {product.stockQuantity} restant{product.stockQuantity > 1 ? 's' : ''}
              </span>
            )}
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <Link
              to={`/products/${product.slug}`}
              className="px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 rounded-xl transition-colors text-center flex items-center justify-center gap-1 group/btn"
            >
              <span>{t('product.viewDetails')}</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-slate-400 group-hover/btn:text-slate-700 transition-transform group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5" />
            </Link>

            <button
              onClick={handleWhatsAppClick}
              disabled={isSold}
              className={`px-3 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-xs ${
                isSold
                  ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  : 'bg-[#DC2626] hover:bg-[#B91C1C] active:bg-[#991B1B] text-white shadow-red-600/20 hover:shadow-md'
              }`}
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>{isSold ? t('statuses.sold') : t('product.orderWhatsApp')}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
