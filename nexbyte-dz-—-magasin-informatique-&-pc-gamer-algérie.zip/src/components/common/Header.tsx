import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { Link, useRouter } from '../../router/Router';
import { openWhatsAppChat } from '../../services/whatsappService';
import { 
  Menu, 
  X, 
  MessageCircle, 
  Search, 
  Globe, 
  SlidersHorizontal,
  ChevronDown,
  Sparkles,
  PhoneCall
} from 'lucide-react';

export const Header: React.FC = () => {
  const { language, setLanguage, t } = useLanguage();
  const { pathname, navigate } = useRouter();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 15);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?search=${encodeURIComponent(searchQuery.trim())}`);
      setSearchOpen(false);
      setMobileMenuOpen(false);
    }
  };

  const navLinks = [
    { to: '/', label: t('nav.home'), exact: true },
    { to: '/categories/laptops', label: t('nav.laptops') },
    { to: '/categories/gaming-pc', label: t('nav.gamingPc') },
    { to: '/categories/gpus', label: t('nav.components') },
    { to: '/offers', label: t('nav.offers'), highlight: true },
  ];

  const languages = [
    { code: 'fr', label: 'Français', flag: '🇫🇷' },
    { code: 'ar', label: 'العربية', flag: '🇩🇿' },
    { code: 'en', label: 'English', flag: '🇬🇧' },
  ];

  return (
    <header 
      className={`sticky top-0 z-40 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white/95 backdrop-blur-md border-b border-slate-200/90 shadow-xs' 
          : 'bg-white/80 backdrop-blur-xs border-b border-slate-200/60'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-6 h-18">
          
          {/* Zone 1: Brand Wordmark (Single Element) */}
          <Link to="/" className="flex items-center gap-3 whitespace-nowrap shrink-0 group">
            {/* Sleek Crimson Tech Monogram */}
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#DC2626] to-[#991B1B] flex items-center justify-center p-[1px] shadow-sm shadow-red-500/25 group-hover:scale-105 transition-transform">
              <div className="w-full h-full bg-white rounded-[11px] flex items-center justify-center">
                <span className="text-xs font-black tracking-tight text-[#DC2626]">
                  YI
                </span>
              </div>
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-extrabold tracking-tight text-slate-900 group-hover:text-slate-700 transition-colors">
                YOUPPI<span className="text-[#DC2626] ms-1">INFO</span>
              </span>
              <span className="text-[10px] font-semibold text-slate-400 tracking-wider uppercase -mt-1 hidden sm:block">
                Informatique & Gaming DZ
              </span>
            </div>
          </Link>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-600">
            {navLinks.map((link) => {
              const active = link.exact ? pathname === link.to : pathname.startsWith(link.to);
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  className={`whitespace-nowrap shrink-0 transition-colors py-1.5 px-1 relative ${
                    active 
                      ? 'text-slate-900 font-bold after:absolute after:bottom-0 after:left-1 after:right-1 after:h-[2px] after:bg-[#DC2626] after:rounded-full' 
                      : 'text-slate-600 hover:text-slate-900'
                  } ${link.highlight && !active ? 'text-[#DC2626] font-semibold' : ''}`}
                >
                  {link.label}
                  {link.highlight && (
                    <span className="absolute -top-1 -right-2 w-1.5 h-1.5 rounded-full bg-[#DC2626]" />
                  )}
                </Link>
              );
            })}
          </nav>

          {/* Zone 3: Actions (Search, Language, Primary WhatsApp CTA) */}
          <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
            {/* Search Trigger */}
            <button
              onClick={() => setSearchOpen(!searchOpen)}
              className="p-2 text-slate-600 hover:text-slate-900 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
              aria-label="Rechercher un produit"
              title="Rechercher"
            >
              <Search className="w-4 h-4" />
            </button>

            {/* Language Selector Dropdown */}
            <div className="relative">
              <button
                onClick={() => setLangMenuOpen(!langMenuOpen)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 rounded-xl border border-slate-200/90 hover:bg-slate-50 transition-colors cursor-pointer"
                aria-label="Changer de langue"
              >
                <Globe className="w-3.5 h-3.5 text-[#DC2626]" />
                <span className="uppercase tracking-wider">{language}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {langMenuOpen && (
                <div 
                  className="absolute right-0 rtl:right-auto rtl:left-0 mt-2 w-36 bg-white border border-slate-200 rounded-xl shadow-xl py-1.5 z-50 text-xs animate-fadeIn"
                  onClick={() => setLangMenuOpen(false)}
                >
                  {languages.map((l) => (
                    <button
                      key={l.code}
                      onClick={() => setLanguage(l.code as any)}
                      className={`w-full text-start px-3.5 py-2 flex items-center gap-2 transition-colors cursor-pointer ${
                        language === l.code
                          ? 'text-[#DC2626] bg-red-50/80 font-bold'
                          : 'text-slate-700 hover:bg-slate-50 hover:text-slate-900'
                      }`}
                    >
                      <span>{l.flag}</span>
                      <span>{l.label}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Primary Action: Direct WhatsApp Order / Quote */}
            <button
              onClick={() => openWhatsAppChat({ sourcePage: pathname, lang: language })}
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-[#DC2626] hover:bg-[#B91C1C] active:bg-[#991B1B] rounded-xl shadow-sm shadow-red-600/25 transition-all duration-200 whitespace-nowrap shrink-0 hover:shadow-md cursor-pointer"
            >
              <MessageCircle className="w-4 h-4" />
              <span>{t('nav.whatsappDirect')}</span>
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-600 hover:text-slate-900 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
              aria-label="Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Expandable Search Input Bar */}
        {searchOpen && (
          <div className="py-3 border-t border-slate-100 animate-fadeIn">
            <form onSubmit={handleSearchSubmit} className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 rtl:left-auto rtl:right-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={t('nav.searchPlaceholder')}
                  autoFocus
                  className="w-full bg-slate-50 border border-slate-200 focus:border-[#DC2626] rounded-xl ps-10 pe-4 py-2.5 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-red-100"
                />
              </div>
              <button
                type="submit"
                className="px-5 py-2.5 bg-[#DC2626] hover:bg-[#B91C1C] text-white text-xs font-bold rounded-xl transition-colors whitespace-nowrap cursor-pointer"
              >
                {t('catalog.search')}
              </button>
              <button
                type="button"
                onClick={() => setSearchOpen(false)}
                className="p-2 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </form>
          </div>
        )}
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 px-4 pt-3 pb-6 space-y-4 shadow-xl animate-fadeIn">
          <nav className="flex flex-col space-y-1">
            {navLinks.map((link) => {
              const active = link.exact ? pathname === link.to : pathname.startsWith(link.to);
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-colors ${
                    active 
                      ? 'bg-red-50 text-[#DC2626]' 
                      : 'text-slate-700 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
            <Link
              to="/products"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3.5 py-2.5 rounded-xl text-sm font-semibold text-slate-700 hover:bg-slate-50 hover:text-slate-900 flex items-center justify-between"
            >
              <span>{t('nav.products')}</span>
              <SlidersHorizontal className="w-4 h-4 text-slate-400" />
            </Link>
            <Link
              to="/about"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3.5 py-2.5 rounded-xl text-sm font-semibold text-slate-700 hover:bg-slate-50 hover:text-slate-900"
            >
              {t('nav.about')}
            </Link>
            <Link
              to="/contact"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3.5 py-2.5 rounded-xl text-sm font-semibold text-slate-700 hover:bg-slate-50 hover:text-slate-900"
            >
              {t('nav.contact')}
            </Link>
          </nav>

          <div className="pt-3 border-t border-slate-100 flex flex-col gap-2.5">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                openWhatsAppChat({ sourcePage: pathname, lang: language });
              }}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 text-sm font-bold text-white bg-[#DC2626] rounded-xl shadow-sm"
            >
              <MessageCircle className="w-4 h-4" />
              <span>{t('nav.whatsappDirect')}</span>
            </button>
            <Link
              to="/admin/login"
              onClick={() => setMobileMenuOpen(false)}
              className="text-center text-xs text-slate-400 hover:text-slate-700 py-1"
            >
              {t('nav.admin')}
            </Link>
          </div>
        </div>
      )}
    </header>
  );
};
